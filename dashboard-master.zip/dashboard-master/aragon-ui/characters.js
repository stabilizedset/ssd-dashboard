'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var NO_BREAK_SPACE = "\xA0";

exports.NO_BREAK_SPACE = NO_BREAK_SPACE;
//# sourceMappingURL=characters.js.map
