'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var GU = 8;
var RADIUS = 4;

exports.GU = GU;
exports.RADIUS = RADIUS;
//# sourceMappingURL=constants.js.map
